package org.projects.ThaliaUtility;

import java.util.concurrent.atomic.AtomicInteger;

public class UniqueIdGenerator {
    static AtomicInteger atomicInteger = new AtomicInteger(122);
    public static Integer getUniqueID() {
        return atomicInteger.incrementAndGet();
    }
}
