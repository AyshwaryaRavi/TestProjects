package org.projects.TestSuiteThaliaUtility;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Test;
import org.projects.Thalia.Seating;
import org.projects.Thalia.SectionInfo;
import org.projects.Thalia.Shows;
import org.projects.Thalia.Tickets;
import org.projects.ThaliaUtility.ExclusionStrategyForTickets;

import com.google.gson.FieldAttributes;

public class ExclusionStrategyForTicketsTest {

    String selection = "getSpecificSection";
    ExclusionStrategyForTickets e = new ExclusionStrategyForTickets(selection);
	@Test
	public void test() {
		assertSame(false,e.shouldSkipClass(getClass()));
		
	}

}
