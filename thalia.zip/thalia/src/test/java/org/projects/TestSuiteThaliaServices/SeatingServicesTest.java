package org.projects.TestSuiteThaliaServices;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.projects.ThaliaServices.SeatingServices;

import com.github.fge.jsonschema.cfg.ValidationConfiguration;
import com.github.fge.jsonschema.main.JsonSchemaFactory;

import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import static io.restassured.response.Response.*;

import io.restassured.http.ContentType;
import io.restassured.module.jsv.JsonSchemaValidator;

public class SeatingServicesTest {

	@Before
	public  void setup()
	{
	baseURI = "http://localhost";
	port = 8080;
	basePath = "/Thalia";
	}
	
	@Test
	public void test_GETSeating() { 
		
	    int code = get("/seating").statusCode();
	    assertEquals(200,code);
		get("/seating").then().assertThat().contentType(ContentType.JSON);
		Response response = when().get("/seating").then().contentType(ContentType.JSON).extract().response();	
		String s = response.getBody().prettyPrint();
		assertTrue(s.contains("Front right"));
		assertTrue(s.contains("Front center"));
		assertTrue(s.contains("Front left"));
		assertTrue(s.contains("Main center"));
		assertTrue(s.contains("Main right"));
		assertTrue(s.contains("Main left"));
		assertTrue(s.contains("sid"));
		assertTrue(s.contains("section_name"));

		
 }
	@Test
	public void test_GETSeatingID() { 
		
	    int code = get("/seating/1").statusCode();
	    assertEquals(200,code);
		get("/seating/1").then().assertThat().contentType(ContentType.JSON);
		Response response = when().get("/seating/1").then().contentType(ContentType.JSON).extract().response();	
		String s = response.getBody().prettyPrint();
	
		
 }
	
 @Test
 public void test_ClassSeatingServices()
 {
	 SeatingServices s = new SeatingServices();
	 assertEquals("{\"Result\":\"Notfound\"}",s.getSpecificSection("1").getEntity().toString());
	 assertEquals(200,s.getSections("7", "1", "4", "9").getStatus());

	 
 }
}