package org.projects.TestSuiteThaliaServices;

import static io.restassured.RestAssured.basePath;
import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.port;
import static io.restassured.RestAssured.when;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.projects.Thalia.Donations;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class TicketServicesTest {

	@Before
	public  void setup()
	{
	baseURI = "http://localhost";
	port = 8080;
	basePath = "/Thalia";
	}

	@Test
	public void test_Donations() { 
		
		Donations donations = new Donations();
		List<String> st= new ArrayList<>();
		st.add("1");
		st.add("2");
		donations.setTickets(st);
		   int code= given().
		    	       contentType("application/json; charset=UTF-16").
		    	       body(donations).
		    	      post("/tickets/donations").getStatusCode() ;
		   assertEquals(200, code);
		
 }

}
