package org.projects.TestSuiteThaliaServices;

import static io.restassured.RestAssured.basePath;
import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.when;
import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.port;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.projects.Thalia.Donations;
import org.projects.Thalia.Seating;
import org.projects.Thalia.SeatingShows;
import org.projects.Thalia.SectionInfo;
import org.projects.Thalia.ShowInfo;
import org.projects.Thalia.Shows;
import org.projects.ThaliaServices.SeatingServices;
import org.projects.ThaliaServices.ShowServices;

import com.google.gson.Gson;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class ShowServicesTest {

	@Before
	public  void setup()
	{
	baseURI = "http://localhost";
	port = 8080;
	basePath = "/Thalia";
	}

	@Test
	 public void testShowService() {
		List<SectionInfo> sectionInfoList = new ArrayList<>();
		SectionInfo sectionInfo = new SectionInfo();
		sectionInfo.setSectionName("");
		List<Seating> seating = new ArrayList<>();
		sectionInfo.setSeating(seating);
		sectionInfoList.add(sectionInfo);
		Shows show = new Shows();
		  ShowInfo showInfo = new ShowInfo("Madison Heights","www.shows.com","12-09-2016","14:00");
		  show.setShowInfo(showInfo);
		show.setSectionInfo(sectionInfoList);
		show.setTotalAmount(0L);
		SeatingShows s = new SeatingShows(show);
		
		showInfo.setName("Alex");
		showInfo.setTime("12:00");
		showInfo.setWeb("example.com");
		showInfo.setDate("12-01-2017");
		show.setWid("708");
		show.setDonatedAndUsedTickets(3L);
		show.setDonatedAndUsedValue(180L);
		show.setDonatedTickets(2L);
		show.setOccupancy("40%");
		show.setSeatsAvailable(4L);
		show.setSeatsSold(1L);
		show.setStartingSeatId("21");
		show.setStatus("open"); 
		show.setTotalAmount(250L);
		show.setShowInfo(showInfo);
		
String rs= given().
contentType("application/json; charset=UTF-16").
body(show).
post("/shows").getBody().prettyPrint() ;
assertTrue(rs.contains("wid"));;

String r= given().
contentType("application/json; charset=UTF-16").
body(show).
get("/shows/86").getBody().prettyPrint() ;


/*int p = given().
contentType("application/json; charset=UTF-16").
body(show).
put("/shows/30").getStatusCode();
assertEquals(200,p);*/

String g = given().
contentType("application/json; charset=UTF-16").
body(show).
get("/shows/86/sections").getBody().prettyPrint() ;
//assertTrue(g.contains("null"));

String h = given().
contentType("application/json; charset=UTF-16").
body(show).
post("/shows/86/donations").getBody().prettyPrint() ;
//assertTrue(g.contains("null"));


String i = given().
contentType("application/json; charset=UTF-16").
body(show).
post("/shows/86/donations/97").getBody().prettyPrint() ;
//assertTrue(g.contains("null"));


String j = given().
contentType("application/json; charset=UTF-16").
body(show).
post("/86/sections/1").getBody().prettyPrint() ;
//assertTrue(g.contains("null"));

    }
	 @Test
	 public void test_ClassShowServices()
	 {
		
		 ShowServices s = new ShowServices();
		 assertEquals("{\"Result\":\"Notfound\"}",s.getShow("7").getEntity().toString());
		 assertEquals(200,s.getDonations("8", "9").getStatus());
		 assertEquals("{\"Result\":\"Notfound\"}",s.getShowSection("1").getEntity().toString());
		 assertEquals(200,s.getDonations("8", "9").getStatus()); 
	 }


}
