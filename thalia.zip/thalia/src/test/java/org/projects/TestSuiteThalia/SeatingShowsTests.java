package org.projects.TestSuiteThalia;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Test;
import org.projects.Thalia.Seat;
import org.projects.Thalia.Seating;
import org.projects.Thalia.SeatingShows;
import org.projects.Thalia.SectionInfo;
import org.projects.Thalia.ShowInfo;
import org.projects.Thalia.ShowSections;
import org.projects.Thalia.Shows;

public class SeatingShowsTests {


	
	List<SectionInfo> sectionInfo = new ArrayList<>();
	List<Seating> seating = new ArrayList<>();
	
	@Test
	public void test_gettersANDSetters()
	{
		Shows show = new Shows();
		  ShowInfo showInfo = new ShowInfo();
		  show.setShowInfo(showInfo);
		show.setSectionInfo(sectionInfo);
		show.setTotalAmount(0L);
		SeatingShows s = new SeatingShows(show);
		
		showInfo.setName("Alex");
		showInfo.setTime("12:00");
		showInfo.setWeb("example.com");
		showInfo.setDate("12-01-2017");
		show.setWid("708");
		show.setDonatedAndUsedTickets(3L);
		show.setDonatedAndUsedValue(180L);
		show.setDonatedTickets(2L);
		show.setOccupancy("40%");
		show.setSeatsAvailable(4L);
		show.setSeatsSold(1L);
		show.setStartingSeatId("21");
		show.setStatus("open");
		show.setTotalAmount(250L);
		show.setShowInfo(showInfo);
		show.setSectionInfo(sectionInfo);
		s.setSeating(seating);
		s.setSectionName("Front right");
		s.setSid("1");
		s.setStartingSeatId("2");
		s.setStatus("open");
		s.setTotalAmount(180);
		s.setWid("7");
		s.setShowInfo(showInfo);
		
		assertEquals("7", s.getWid());
		assertEquals(180,s.getTotalAmount().intValue());
		assertEquals("open", s.getStatus());
		assertEquals("2", s.getStartingSeatId());
		assertEquals("1", s.getSid());
		assertEquals("Front right", s.getSectionName());
		assertEquals(seating, s.getSeating());
		assertEquals(showInfo.getName(),s.getShowInfo().getName());
		
	}
	@Test
	public void test__anotherparamterizedConstructor()
	{

		Shows show = new Shows();
		  ShowInfo showInfo = new ShowInfo("Madison Heights","www.shows.com","12-09-2016","14:00");
		  show.setShowInfo(showInfo);
		  show.setSectionInfo(sectionInfo);
			show.setTotalAmount(0L);
		SeatingShows s = new SeatingShows(show);
		SectionInfo section = new SectionInfo();
		List<Seating>seat = new ArrayList<>();
		Seating set = new Seating();
		Seat seating = new Seat();
		
		seating.setCid("8");
		seating.setSeat("1");
		seating.setStatus("ok");
		
		
		
        section.setSectionName("Front Right");	
        section.setPrice(75L);
        section.setSeatsAvailable(4L);
        section.setSeatsSold(2L);
        section.setSectionPrice(180L);
        section.setSectionRevenue(450L);
        section.setSid("1");
        section.setSeating(seat);
        
        sectionInfo.add(section);
		showInfo.setName("Alex");
		showInfo.setTime("12:00");
		showInfo.setWeb("example.com");
		showInfo.setDate("12-01-2017");
		show.setWid("7");
		show.setDonatedAndUsedTickets(3L);
		show.setDonatedAndUsedValue(180L);
		show.setDonatedTickets(2L);
		show.setOccupancy("40%");
		show.setSeatsAvailable(4L);
		show.setSeatsSold(1L);
		show.setStartingSeatId("21");
		show.setStatus("open");
		show.setTotalAmount(250L);
		show.setShowInfo(showInfo);
		show.setSectionInfo(sectionInfo);
		s.setSeating(seat);
		s.setSectionName("Front Right");
		s.setSid("1");
		s.setStartingSeatId("2");
		s.setStatus("open");
		s.setTotalAmount(250);
		s.setWid("7");
		ShowSections s1	 = new ShowSections(show);
		s1 = new ShowSections(show);
		ShowInfo showinfo = new ShowInfo(show.getShowInfo());
	
	
		assertEquals(s1.getSeating(), s.getSeating());
		assertEquals(s1.getSectionName(), s.getSectionName());
		assertEquals(show.getWid(), s.getWid());	
		
		
	}


}
